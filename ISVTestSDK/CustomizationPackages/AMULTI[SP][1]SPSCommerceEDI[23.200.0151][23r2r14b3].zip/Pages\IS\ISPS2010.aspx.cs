using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PX.Web.UI;
using System.Drawing;

public partial class  Page_ISPS2010 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterStyle("CssOverdue", null, "Red", false);
        PXTextEdit myfield = (PXTextEdit)form.FindControl("edsyncMessage");
        myfield.CssClass = "CssOverdue";

    }
    private void RegisterStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor)) style.BackColor = Color.FromName(backColor);
        if (!string.IsNullOrEmpty(foreColor)) style.ForeColor = Color.FromName(foreColor);
        if (bold) style.Font.Bold = true;
        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }
}
