using Mapadoc;
using PX.Data;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_ISPS5012 : PX.Web.UI.PXPage
{
	protected void Page_Init(object sender, EventArgs e)
	{
	}

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        PXResult record = e.Row.DataItem as PXResult;
        if (record == null) return;

        ISPSSOOrder viewInfo = (ISPSSOOrder)record[typeof(ISPSSOOrder)];
        bool isBold = viewInfo != null && (viewInfo.ErrorStatus == "4");

        //  EPActivity item = (EPActivity)record[typeof(EPActivity)];


        //e.Row.Style.CssClass = (isBold ? "CssBoldOver" : "CssOver");
        if (isBold) e.Row.Style.ForeColor =System.Drawing.Color.Red;
    }
}
